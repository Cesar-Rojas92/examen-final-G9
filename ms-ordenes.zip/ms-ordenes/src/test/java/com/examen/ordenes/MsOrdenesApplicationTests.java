package com.examen.ordenes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsOrdenesApplicationTests {

	@Test
	void contextLoads() {
	}

}
