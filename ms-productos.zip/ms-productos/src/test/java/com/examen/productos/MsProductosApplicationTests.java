package com.examen.productos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
